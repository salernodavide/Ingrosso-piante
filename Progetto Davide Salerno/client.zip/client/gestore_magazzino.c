#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"


void aggiungi_fornitore(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[7];

	int codice_fornitore;
	char nome[46];
	char codice_fiscale[17];
	char via[46], citta[46];
    int civico;
    char specie_fornita[46];

	puts("Inserisci il codice del fornitore da aggiungere");
    scanf("%d", &codice_fornitore);
    getchar();
    puts("Inserisci il nome del fornitore da aggiungere");
    getInput(46, nome, false);
    puts("Inserisci il codice fiscale del fornitore da aggiungere");
    getInput(17, codice_fiscale, false);
    puts("Inserisci la via della sede principale del fornitore da aggiungere");
    getInput(46, via, false);
    puts("Inserisci il numero civico della sede principale del fornitore da aggiungere");
    scanf("%d", &civico);
    getchar();
    puts("Inserisci la città della sede principale del fornitore da aggiungere");
    getInput(46, citta, false);
    puts("Inserisci una specie fornita dal fornitore da aggiungere");
    getInput(46, specie_fornita, false);

	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_fornitore(?,?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement aggiungi_fornitore\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &codice_fornitore;
	param[0].buffer_length = sizeof(codice_fornitore);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[1].buffer = nome;
    param[1].buffer_length = strlen(nome);

    param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[2].buffer = codice_fiscale;
    param[2].buffer_length = strlen(codice_fiscale);

    param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[3].buffer = via;
    param[3].buffer_length = strlen(via);

    param[4].buffer_type = MYSQL_TYPE_LONG;
    param[4].buffer = &civico;
    param[4].buffer_length = sizeof(civico);

    param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[5].buffer = citta;
    param[5].buffer_length = strlen(citta);

	param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[6].buffer = specie_fornita;
    param[6].buffer_length = strlen(specie_fornita);



	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for aggiungi fornitore\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding fornitore.");
	} else {
		printf("Fornitore correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}


void aggiungi_indirizzo_fornitore(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[4];

    int codice_fornitore;
	char via[46], citta[46];
    int civico;

    puts("Inserisci il codice del fornitore");
	scanf("%d", &codice_fornitore);
	getchar();
	puts("Inserisci la via da aggiungere");
	getInput(46, via, false);
	puts("Inserisci il numero civico da aggiungere");
	scanf("%d", &civico);
	getchar();
	puts("Inserisci la città da aggiungere");
	getInput(46, citta, false);


	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_indirizzo_fornitore(?, ?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement aggiungi indirizzo\n", false);
	}

	memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[0].buffer = via;
    param[0].buffer_length = strlen(via);

    param[1].buffer_type = MYSQL_TYPE_LONG;
    param[1].buffer = &civico;
    param[1].buffer_length = sizeof(civico);

    param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[2].buffer = citta;
    param[2].buffer_length = strlen(citta);

    param[3].buffer_type = MYSQL_TYPE_LONG;
    param[3].buffer = &codice_fornitore;
    param[3].buffer_length = sizeof(codice_fornitore);


	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for adding address\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding address.");
	} else {
		printf("Address correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void aggiungi_specie(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

	char codice_fornitore[46];
    char codice_specie[46];

	puts("Inserisci il codice del fornitore");
	getInput(46, codice_fornitore, false);
    puts("Inserisci il codice della specie fornita");
	getInput(46, codice_specie, false);

	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_specie_fornita(?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement aggiungi specie fornita\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = codice_fornitore;
	param[0].buffer_length = strlen(codice_fornitore);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = codice_specie;
	param[1].buffer_length = strlen(codice_specie);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for aggiungi specie fornita\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while aggiungi specie fornita.");
	} else {
		printf("Specie correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void specie_da_rifornire(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;

    if(!setup_prepared_stmt(&prepared_stmt, "call specie_da_rifornire()", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize specie_da_rifornire\n", false);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show species\n", true);
	}

    dump_result_set(conn, prepared_stmt, "\nList of species");
        if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi consuma il result set
            finish_with_stmt_error(conn, prepared_stmt, "Error", true);
        }

	mysql_stmt_close(prepared_stmt);
}

void richiesta_rifornimento(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[3];

	char speci[256];
	char quantita[256];
	char stringa[46];
	char stringa_quantita[46];
	int codice_fornitore;
	int num, l;

	puts("Inserisci il codice del fornitore a cui si commissiona il rifornimento");
	fflush(stdin);
	scanf("%d", &codice_fornitore);
	getchar();


	puts("Quante speci vuoi richiedere?");
	scanf("%d", &num);
	getchar();
    fflush(stdin);

    memset(speci, 0, sizeof(speci));
    memset(quantita, 0, sizeof(quantita));
    strcpy(speci, "");
    strcpy(quantita, "");
	for (int i=0; i<num; i++){
        puts("Inserisci codice specie da richiedere");
        getInput(45, stringa, false);
        l = strlen(stringa);
        stringa[l] = '.';
        stringa[l+1] = '\0';
        sprintf(speci+strlen(speci), "%s", stringa);

        puts("Inserisci quantità da richiedere");
        getInput(45, stringa_quantita, false);
        l = strlen(stringa_quantita);
        stringa_quantita[l] = '.';
        stringa_quantita[l+1] = '\0';
        sprintf(quantita+strlen(quantita), "%s", stringa_quantita);
    }
    printf("%s\n", speci);
    printf("%s\n", quantita);

	if(!setup_prepared_stmt(&prepared_stmt, "call richiesta_rifornimento(?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement richiesta rifornimento\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &codice_fornitore;
	param[0].buffer_length = sizeof(codice_fornitore);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = speci;
	param[1].buffer_length = strlen(speci);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = quantita;
	param[2].buffer_length = strlen(quantita);


	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for richiesta\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while richiesta rifornimento.");
	} else {
		printf("Richiesta correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void warehouse(MYSQL *conn)
{
	char options[6] = {'1','2','3','4','5','6'};
	char op;

	printf("Switching to warehouse role...\n");

	if(!parse_config("users/gestore_magazzino.json", &conf)) {
		fprintf(stderr, "Unable to load warehouse configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Aggiungi un nuovo fornitore\n");
		printf("2) Aggiungi un ulteriore indirizzo al fornitore\n");
		printf("3) Aggiungi una specie alla lista delle speci fornite da un fornitore\n");
		printf("4) Visualizza speci esaurite\n");
		printf("5) Esegui una richiesta di rifornimento\n");
		printf("6) Quit\n");

		op = multiChoice("Select an option", options, 6);

		switch(op) {
			case '1':
				aggiungi_fornitore(conn);
				break;
			case '2':
				aggiungi_indirizzo_fornitore(conn);
				break;
            case '3':
				aggiungi_specie(conn);
				break;
            case '4':
				specie_da_rifornire(conn);
				break;
            case '5':
				richiesta_rifornimento(conn);
				break;
			case '6':
				return;

			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
