#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

extern void plant_list(MYSQL *conn);
extern char* pulisci_stringa (char *stringhe);

void add_plant_species(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[7];

	char codice_specie[46];
	char nome_comune[46];
	char nome_latino[46];
	int da_interno;
	int esotica;
	float prezzo;
	char array_colori[256];
	char* stringa_pulita;
	char stringa[46];
	int num_colorazioni, l;
	char options[2] = {'1','2'};
    char r;

	puts("Inserisci il codice della specie da aggiungere");
	getInput(46, codice_specie, false);
	puts("Inserisci il nome comune della specie da aggiungere");
	getInput(46, nome_comune, false);
	puts("Inserisci nome latino della specie da aggiungere");
	getInput(46, nome_latino, false);
	puts("E' una specie da interno?");
    printf("\t1) Si\n");
    printf("\t2) No\n");
    r = multiChoice("Select 1 o 2", options, 2);
    if (r == 1){
        da_interno = 1;
    }
    else {
        da_interno = 0;
    }
	puts("E' una specie esotica?");
    printf("\t1) Si\n");
    printf("\t2) No\n");
    r = multiChoice("Select 1 o 2", options, 2);
    if (r == 1){
        esotica = 1;
    }
    else {
        esotica = 0;
    }
	puts("Inserisci il prezzo della specie da aggiungere");
	scanf("%f", &prezzo);
	getchar();
	puts("In quante colorazioni è disponibile?");
	scanf("%d", &num_colorazioni);
	getchar();
	fflush(stdin);

    if (num_colorazioni == 0){
        strcpy(array_colori, "-");
    }
    memset(array_colori, 0, sizeof(array_colori));
    strcpy(array_colori, "");
	for (int i=0; i<num_colorazioni; i++){
        puts("Inserisci colorazione");
        fflush(stdin);
        getInput(45, stringa, false);
        l = strlen(stringa);
        stringa[l] = '.';
        stringa[l+1] = '\0';
        sprintf(array_colori+strlen(array_colori), "%s", stringa);
    }
    stringa_pulita = pulisci_stringa(array_colori);
	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_specie(?, ?, ?, ?, ?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement add_plant_species\n", false);
		free(stringa_pulita);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = codice_specie;
	param[0].buffer_length = strlen(codice_specie);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = nome_comune;
	param[1].buffer_length = strlen(nome_comune);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = nome_latino;
	param[2].buffer_length = strlen(nome_latino);

	param[3].buffer_type = MYSQL_TYPE_TINY;
	param[3].buffer = &da_interno;
	param[3].buffer_length = sizeof(da_interno);

	param[4].buffer_type = MYSQL_TYPE_TINY;
	param[4].buffer = &esotica;
	param[4].buffer_length = sizeof(esotica);

	param[5].buffer_type = MYSQL_TYPE_FLOAT;
	param[5].buffer = &prezzo;
	param[5].buffer_length = sizeof(prezzo);

	param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[6].buffer = stringa_pulita;
	param[6].buffer_length = strlen(stringa_pulita);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for adding species\n", true);
        free(stringa_pulita);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding species.");
	} else {
		printf("Species correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
	free(stringa_pulita);
}

void show_species(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;

    if(!setup_prepared_stmt(&prepared_stmt, "call lista_speci_ordinate()", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show species\n", false);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show species\n", true);
	}

	dump_result_set(conn, prepared_stmt, "\nList of species");
    if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera il result set
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
	mysql_stmt_close(prepared_stmt);
}

void show_past_price_lists(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
    MYSQL_BIND param[1];

    char specie[46];

    puts("A quale specie sei interessato?");
    getInput(46, specie, false);


    if(!setup_prepared_stmt(&prepared_stmt, "call listini_passati(?)", conn)) {
        finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize listini passati\n", false);
    }

    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = specie;
	param[0].buffer_length = strlen(specie);

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
        finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for listini passati\n", true);
    }

    if (mysql_stmt_execute(prepared_stmt) != 0) {
        finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve listini passati\n", true);
    }

    dump_result_set(conn, prepared_stmt, "\nList of past price");
    if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
    mysql_stmt_close(prepared_stmt);
}

void edit_price_list(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

	char specie[46];
	float costo;

	puts("Inserisci il codice della specie");
	getInput(46, specie, false);

    puts("Inserisci il nuovo prezzo");
	scanf("%f", &costo);
	getchar();

	if(!setup_prepared_stmt(&prepared_stmt, "call nuovo_listino(?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement nuovo listino\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = specie;
	param[0].buffer_length = strlen(specie);

	param[1].buffer_type = MYSQL_TYPE_FLOAT;
	param[1].buffer = &costo;
	param[1].buffer_length = sizeof(costo);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for adding a new price\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while editing price.");
	} else {
		printf("Price correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}



void manager(MYSQL *conn)
{
	char options[6] = {'1','2','3','4','5','6'};
	char op;

	printf("Switching to manager role...\n");

	if(!parse_config("users/manager.json", &conf)) {
		fprintf(stderr, "Unable to load manager configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Add plant species\n");
		printf("2) Show species\n");
		printf("3) Show plants\n");
		printf("4) Show past price lists\n");
		printf("5) Edit a price list\n");
		printf("6) Quit\n");

		op = multiChoice("Select an option", options, 6);

		switch(op) {
			case '1':
				add_plant_species(conn);
				break;
			case '2':
				show_species(conn);
				break;
            case '3':
				plant_list(conn);
				break;
            case '4':
				show_past_price_lists(conn);
				break;
            case '5':
				edit_price_list(conn);
				break;
			case '6':
				return;

			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
