#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

void add_customer(MYSQL *conn, char username1[46]);

void create_user(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[3];
	char options[5] = {'1','2','3','4','5'};
	char r;

	// Input for the registration routine
	char username[46];
	char password[46];
	char ruolo[46];

	// Get the required information
	printf("\nUsername: ");
	getInput(46, username, false);
	printf("password: ");
	getInput(46, password, true);
	printf("Assign a possible role:\n");
	printf("\t1) Amministratore\n");
	printf("\t2) Cliente\n");
	printf("\t3) Gestore del magazzino\n");
	printf("\t4) Manager\n");
	printf("\t5) Operatore pacchi\n");
	r = multiChoice("Select role", options, 5);

	// Convert role into enum value
	switch(r) {
		case '1':
			strcpy(ruolo, "amministratore");
			break;
		case '2':
			strcpy(ruolo, "cliente");
			break;
		case '3':
			strcpy(ruolo, "gestore_magazzino");
			break;
        case '4':
			strcpy(ruolo, "manager");
			break;
        case '5':
			strcpy(ruolo, "operatore");
			break;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
	}

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call crea_utente(?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize user insertion statement\n", false);
		goto out;
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = password;
	param[1].buffer_length = strlen(password);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = ruolo;
	param[2].buffer_length = strlen(ruolo);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for user insertion\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the user.");
		goto out;
	} else {
		printf("User correctly added...\n");
	}

	if (strcmp(ruolo, "cliente") == 0){
        add_customer(conn, username);
    }

out: mysql_stmt_close(prepared_stmt);
}

void info_order(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];

    int ordine;

    puts("Inserisci codice ordine");
    scanf("%d", &ordine);
    getchar();

    if(!setup_prepared_stmt(&prepared_stmt, "call visualizza_info_ordine(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show info order\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &ordine;
	param[0].buffer_length = sizeof(ordine);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for show info order\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show info order\n", true);
	}

	dump_result_set(conn, prepared_stmt, "\nOrder info:");
	if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
	mysql_stmt_close(prepared_stmt);
}

void add_customer(MYSQL *conn, char username1[46]){
    MYSQL_STMT *prepared_stmt;
    MYSQL_BIND param[14];

    char username[46];
    char recapito_preferito[46];
    char nome[46];
    char tipo[10];
    char via[46], citta[46], via_fatturazione[46], citta_fatturazione[46];
    int civico, civico_fatturazione;
    char codice_fiscale[17] = {'-','\0'};
    char partita_IVA[12] = {'-','\0'};
    char referente[46] = {'-','\0'};
    char recapito_referente[46] = {'-','\0'};
    char options1[2] = {'1','2'};
    char r1;
    char r2;

    puts("Inserisci dati cliente");
    if (strcmp(username1, " ")==0){
        printf("\nUsername: ");
        getInput(46, username, false);
    }
    else {
        strcpy(username, username1);
    }
    puts("Iserisci il nome");
    getInput(46, nome, false);
    puts("Inserisci la via di residenza");
    getInput(46, via, false);
    puts("Inserisci il numero civico");
    scanf("%d", &civico);
    getchar();
    puts("Inserisci città di residenza");
    getInput(46, citta, false);
    puts("Inserisci il recapito principale");
    getInput(46, recapito_preferito, false);
    puts("Inserisci la via di fatturazione");
    getInput(46, via_fatturazione, false);
    puts("Iserisci il civico di fatturazione");
    scanf("%d", &civico_fatturazione);
    getchar();
    puts("Inserisci la città di fatturazione");
    getInput(46, citta_fatturazione, false);

    printf("Assign a possible type:\n");
    printf("\t1) Privato\n");
    printf("\t2) Rivendita\n");
    r1 = multiChoice("Select type", options1, 2);

    switch(r1) {
    case '1':
        strcpy(tipo, "privato");
        puts("Inserisci il tuo codice fiscale");
        getInput(17, codice_fiscale, false);
        break;
    case '2':
        strcpy(tipo, "rivendita");
        puts("Inserisci partita IVA");
        getInput(12, partita_IVA, false);
        puts("Inserisci il nome del referente di rivendita");
        getInput(46, referente, false);
        puts("Vuoi inserire un recapito del referente della rivendita?");
        printf("\t1) Si\n");
        printf("\t2) No\n");
        r2 = multiChoice("Select 1 o 2", options1, 2);
        if (r2 == 1){
            puts("Inserisci il recapito primario del referente");
            getInput(46, recapito_referente, false);
        }
        break;
    default:
        fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
        abort();
    }

    if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_cliente(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", conn)) {
        finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize add customer statement\n", false);
    }

    // Prepare parameters
    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[0].buffer = username;
    param[0].buffer_length = strlen(username);

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[1].buffer = tipo;
    param[1].buffer_length = strlen(tipo);

    param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[2].buffer = recapito_preferito;
    param[2].buffer_length = strlen(recapito_preferito);

    param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[3].buffer = nome;
    param[3].buffer_length = strlen(nome);

    param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[4].buffer = codice_fiscale;
    param[4].buffer_length = strlen(codice_fiscale);

    param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[5].buffer = partita_IVA;
    param[5].buffer_length = strlen(partita_IVA);

    param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[6].buffer = via;
    param[6].buffer_length = strlen(via);

    param[7].buffer_type = MYSQL_TYPE_LONG;
    param[7].buffer = &civico;
    param[7].buffer_length = sizeof(civico);

    param[8].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[8].buffer = citta;
    param[8].buffer_length = strlen(citta);

    param[9].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[9].buffer = via_fatturazione;
    param[9].buffer_length = strlen(via_fatturazione);

    param[10].buffer_type = MYSQL_TYPE_LONG;
    param[10].buffer = &civico_fatturazione;
    param[10].buffer_length = sizeof(civico_fatturazione);

    param[11].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[11].buffer = citta_fatturazione;
    param[11].buffer_length = strlen(citta_fatturazione);

    param[12].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[12].buffer = referente;
    param[12].buffer_length = strlen(referente);

    param[13].buffer_type = MYSQL_TYPE_VAR_STRING;
    param[13].buffer = recapito_referente;
    param[13].buffer_length = strlen(recapito_referente);

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
        finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for add customer\n", true);
    }

    // Run procedure
    if (mysql_stmt_execute(prepared_stmt) != 0) {
        print_stmt_error (prepared_stmt, "An error occurred while adding the customer.");
    } else {
        printf("Customer correctly added...\n");
    }
    mysql_stmt_close(prepared_stmt);
}


void customer_orders(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];

    char username[46];
    puts("Inserisci lo username dell'utente del quale si vogliono controllare gli ordini");
    getInput(46, username, false);

    if(!setup_prepared_stmt(&prepared_stmt, "call visualizza_ordini(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show orders\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for show orders\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show orders\n", true);
	}

	dump_result_set(conn, prepared_stmt, "\nList of orders");
	if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
	mysql_stmt_close(prepared_stmt);
}

void administrator(MYSQL *conn)
{
	char options[5] = {'1','2', '3', '4', '5'};
	char op;

	printf("Switching to administrative role...\n");

	if(!parse_config("users/amministratore.json", &conf)) {
		fprintf(stderr, "Unable to load administrator configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Create new user\n");
		printf("2) Show ordes of a user\n");
		printf("3) Show info order\n");
		printf("4) Record customer's data\n");
		printf("5) Quit\n");

		op = multiChoice("Select an option", options, 5);

		switch(op) {
			case '1':
				create_user(conn);
				break;
			case '2':
				customer_orders(conn);
				break;
			case '3':
				info_order(conn);
				break;
			case '4':
				add_customer(conn, " ");
				break;
			case '5':
				return;

			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
