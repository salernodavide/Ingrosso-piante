#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

void add_plants(MYSQL *conn);
void show_my_orders(MYSQL *conn);
int show_open_orders(MYSQL *conn);

char specie[46];

void add_customer_contact(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

	char recapito[46];

	puts("Inserisci il recapito da aggiungere");
	getInput(46, recapito, false);

	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_contatto_cliente(?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement add_customer_contact\n", false);
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = recapito;
	param[1].buffer_length = strlen(recapito);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for adding contact\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding contact.");
	} else {
		printf("Contact correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void plant_list(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

    int status;
    float costo = 0;

    puts("A quale specie sei interessato?");
    getInput(46, specie, false);

    if(!setup_prepared_stmt(&prepared_stmt, "call piante_specie(?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize plants statement\n", false);
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = specie;
	param[0].buffer_length = strlen(specie);

    param[1].buffer_type = MYSQL_TYPE_FLOAT;
	param[1].buffer = &costo;
	param[1].buffer_length = sizeof(costo);


	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for plant list\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "Could not retrieve plant list\n");
		goto out;
	}


    dump_result_set(conn, prepared_stmt, "\nList of plants of the selected species");

    status = mysql_stmt_next_result(prepared_stmt);
    if (status >0){
        finish_with_stmt_error(conn, prepared_stmt, "Error: passaggio secondo result non riuscito", true);
    }
    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_FLOAT;
    param[0].buffer = &costo;
    param[0].buffer_length = sizeof(costo);

    if(mysql_stmt_bind_result(prepared_stmt, param)) {
        finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve output parameter", true);
    }


    if(mysql_stmt_fetch(prepared_stmt)) {
        finish_with_stmt_error(conn, prepared_stmt, "Could not buffer results", true);
    }

    printf("Il costo è di: %f €\n", costo);

    out:
	mysql_stmt_close(prepared_stmt);
}

void create_order(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[5];

	char colore[46];
	int quantita;
	int codice = 0;

	plant_list(conn);

	printf("Quale colore vuoi:\n");
	getInput(46, colore, false);
	printf("Inserire la quantità\n");
	scanf("%d", &quantita);
    getchar();

	if(!setup_prepared_stmt(&prepared_stmt, "call crea_ordine(?, ?, ?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize create order statement\n", false);
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = colore;
	param[1].buffer_length = strlen(colore);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = specie;
	param[2].buffer_length = strlen(specie);

	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &quantita;
	param[3].buffer_length = sizeof(quantita);

	param[4].buffer_type = MYSQL_TYPE_LONG;
	param[4].buffer = &codice;
	param[4].buffer_length = sizeof(codice);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for order creation\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while creating order.");
		goto out;
	}

	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &codice;
	param[0].buffer_length = sizeof(codice);

	if(mysql_stmt_bind_result(prepared_stmt, param)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve output parameter", true);
	}

	if(mysql_stmt_fetch(prepared_stmt)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not buffer results", true);
	}

	printf("Order correctly added with ID %d...\n", codice);

    out:
	mysql_stmt_close(prepared_stmt);
}

void add_plants(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[4];

	char colore[46];
	int quantita;
	int codice;

    if(show_open_orders(conn) == 1){
	   puts("Non hai ordini aperti");
	   return;
    }
    puts("Inserici codice ordine a cui inserire piante");
    scanf("%d", &codice);
    getchar();

	plant_list(conn);

	printf("Quale colore vuoi:\n");
	getInput(46, colore, false);
	printf("Inserire la quantità\n");
	scanf("%d", &quantita);
    getchar();


	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_pianta_ordine(?, ?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize add plants statement\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &codice;
	param[0].buffer_length = sizeof(codice);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = specie;
	param[1].buffer_length = strlen(specie);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = colore;
	param[2].buffer_length = strlen(colore);

	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &quantita;
	param[3].buffer_length = sizeof(quantita);


	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for add plants\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "Error: probabilmente hai inserito una quantità di piante superiore alle piante che sono disponibili.\nOrdinane un numero minore, i rifornimenti arriveranno presto.");
	}

	mysql_stmt_close(prepared_stmt);
}

int show_open_orders(MYSQL *conn){
     MYSQL_STMT *prepared_stmt;
	 MYSQL_BIND param[1];

     int risultati;

     if(!setup_prepared_stmt(&prepared_stmt, "call visualizza_ordini_aperti(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show open orders\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for open orders\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve open orders\n", true);
	}
    risultati = dump_result_set(conn, prepared_stmt, "\nList of open orders");

	if (risultati == 0){
        if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
            finish_with_stmt_error(conn, prepared_stmt, "Error", true);
        }
    }
	mysql_stmt_close(prepared_stmt);
	return risultati;
}

void show_my_orders(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];

    if(!setup_prepared_stmt(&prepared_stmt, "call visualizza_ordini(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show orders\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for show orders\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show orders\n", true);
	}

	dump_result_set(conn, prepared_stmt, "\nList of orders");
	if(mysql_stmt_next_result(prepared_stmt)>0){        //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
	mysql_stmt_close(prepared_stmt);
}

void my_info_order(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];

    int ordine;

    show_my_orders(conn);
    puts("Inserisci codice ordine");
    scanf("%d", &ordine);
    getchar();

    if(!setup_prepared_stmt(&prepared_stmt, "call visualizza_info_ordine(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize show info order\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &ordine;
	param[0].buffer_length = sizeof(ordine);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for show info order\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve show info order\n", true);
	}

	dump_result_set(conn, prepared_stmt, "\nOrder info:");
	if(mysql_stmt_next_result(prepared_stmt)>0){   //chiamata che mi libera consuma il result set perchè in caso di DATETIME non mi si consuma del tutto
        finish_with_stmt_error(conn, prepared_stmt, "Error", true);
    }
	mysql_stmt_close(prepared_stmt);
}

void delete_open_order(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

	int ordine;

    if(show_open_orders(conn) == 1){
	   puts("Non hai ordini aperti");
	   return;
    }
	puts("Quale ordine vuoi eliminare?");
	scanf("%d", &ordine);
	getchar();

	if(!setup_prepared_stmt(&prepared_stmt, "call elimina_ordine_aperto(?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Error setup statement delete order\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &ordine;
	param[0].buffer_length = sizeof(ordine);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = conf.username;
	param[1].buffer_length = strlen(conf.username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for delete order\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while deleting order.");
	} else {
		printf("Order correctly delete...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void confirm_order(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[7];

	char via[46];
	char citta[46];
	char recapito[46];
	char referente[46] = {'-','\0'};
	int civico;
	int ordine;
	char options[2] = {'1','2'};
    char r;

    if(show_open_orders(conn) == 1){
	   puts("Non hai ordini aperti");
	   return;
    }
    puts("A ordine vuoi finalizzare?");
    puts("Inserici codice");
    scanf("%d", &ordine);
    getchar();

	puts("Inserisci la via di spedizione");
	getInput(46, via, false);
	printf("Inserire il civico di spedizione\n");
	scanf("%d", &civico);
    getchar();
    puts("Inserire la città di spedizione");
    getInput(46, citta, false);
    puts("Inserire il recapito associato all'ordine");
    getInput(46, recapito, false);
    puts("Si vuole inserire un referente?");
    printf("\t1) Si\n");
    printf("\t2) No\n");
    r = multiChoice("Select 1 o 2", options, 2);
    if (r == 1){
        puts("Inserisci il referente dell'ordine");
        getInput(46, referente, false);
    }

	if(!setup_prepared_stmt(&prepared_stmt, "call finalizza_ordine(?, ?, ?, ?, ?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize confirm order statement\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &ordine;
	param[0].buffer_length = sizeof(ordine);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = via;
	param[1].buffer_length = strlen(via);

	param[2].buffer_type = MYSQL_TYPE_LONG;
	param[2].buffer = &civico;
	param[2].buffer_length = sizeof(civico);

	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = citta;
	param[3].buffer_length = strlen(citta);

    param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = recapito;
	param[4].buffer_length = strlen(recapito);

	param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer = referente;
	param[5].buffer_length = strlen(referente);

	param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[6].buffer = conf.username;
	param[6].buffer_length = strlen(conf.username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for confirm order\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while confirming an order.");
	}

	mysql_stmt_close(prepared_stmt);
}

void customer(MYSQL *conn)
{
	char options[9] = {'1','2','3','4','5','6','7','8','9'};
	char op;

	printf("Switching to customer role...\n");

	if(!parse_config("users/cliente.json", &conf)) {
		fprintf(stderr, "Unable to load customer configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Add another contact\n");
		printf("2) Create order\n");
		printf("3) Add plants\n");
		printf("4) Delete an open order\n");
		printf("5) Confirm order\n");
		printf("6) Show my orders\n");
		printf("7) Show info of a order\n");
		printf("8) Plant species list\n");
		printf("9) Quit\n");

		op = multiChoice("Select an option", options, 9);

		switch(op) {
			case '1':
				add_customer_contact(conn);
				break;
			case '2':
				create_order(conn);
				break;
            case '3':
				add_plants(conn);
				break;
            case '4':
				delete_open_order(conn);
				break;
            case '5':
				confirm_order(conn);
				break;
            case '6':
				show_my_orders(conn);
				break;
            case '7':
				my_info_order(conn);
				break;
            case '8':
				plant_list(conn);
				break;
			case '9':
				return;

			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
